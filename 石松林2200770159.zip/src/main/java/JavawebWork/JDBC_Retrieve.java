package JavawebWork;

import java.sql.*;

public class JDBC_Retrieve {
    static String url = "jdbc:mysql://localhost:3306/DataJDBC";
    static String user = "root";
    static String password = "123456789";
    static String sql = "select * from teacher where id=? ";
    public static void main(String[] args) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection(url, user, password);
            ps = con.prepareStatement(sql);
            ps.setInt(1, 1);


            rs = ps.executeQuery();
            while (rs.next()) {
                System.out.print("id:"+rs.getInt("id")+" ");
                System.out.print("name:"+rs.getString("name")+" ");
                System.out.print("course:"+rs.getString("course")+" ");
                System.out.println("birthday:"+rs.getDate("birthday"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (rs != null) {
                try
                {
                    rs.close();
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
            }
            if (ps != null) {
                try
                {
                    ps.close();
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
            }
            if (con != null) {
                try
                {
                    con.close();
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
