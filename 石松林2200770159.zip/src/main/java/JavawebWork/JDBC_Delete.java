package JavawebWork;

import java.sql.*;

public class JDBC_Delete {
    static String url = "jdbc:mysql://localhost:3306/DataJDBC";
    static String user = "root";
    static String password = "123456789";
    static String sql = "DELETE from teacher where name=? ";
    public static void main(String[] args) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection(url, user, password);
            ps = con.prepareStatement(sql);
            ps.setString(1, "Peter");

            ps.executeUpdate();
            System.out.println("成功删除数据");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (rs != null) {
                try
                {
                    rs.close();
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
            }
            if (ps != null) {
                try
                {
                    ps.close();
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
            }
            if (con != null) {
                try
                {
                    con.close();
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
            }
        }
    }
    }

