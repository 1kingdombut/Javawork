package JavawebWork;

import java.sql.*;
import java.time.LocalDate;
import java.util.Calendar;

public class JDBC_MoreInsert {
    static String url = "jdbc:mysql://localhost:3306/DataJDBC";
    static String user = "root";
    static String password = "123456789";
    static String sql = "INSERT INTO teacher (id, name, course, birthday) VALUES (?,?,?,?) ";

    public static void main(String[] args) {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Date date = new Date(System.currentTimeMillis());
        try {

            con = DriverManager.getConnection(url, user, password);
            con.setAutoCommit(false);
            ps = con.prepareStatement(sql);

            LocalDate localDate = LocalDate.now();
            for (int i = 1; i <= 500; i++) {
                ps.setInt(1, i);
                ps.setString(2, "name" + i);
                ps.setString(3, "course" + i);
                ps.setDate(4, Date.valueOf(localDate.plusDays(i)));
             ps.addBatch();
             if (i % 100 == 0) {
            ps.executeBatch();
            ps.clearBatch();
            }
            }
            ps.executeBatch();
            con.commit();
            System.out.println("Insert completed");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (rs != null) {
                try
                {
                    rs.close();
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
            }
            if (ps != null) {
                try
                {
                    ps.close();
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
            }
            if (con != null) {
                try
                {
                    con.close();
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}