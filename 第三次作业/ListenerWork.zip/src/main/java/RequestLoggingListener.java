import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDateTime;

@WebListener
public class RequestLoggingListener implements ServletRequestListener {

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();

        // 记录请求的详细信息
        String logInfo = String.format("Request Initialized at %s - Method: %s, URI: %s, Client IP: %s, User-Agent: %s",
                LocalDateTime.now(),
                request.getMethod(),
                request.getRequestURI(),
                request.getRemoteAddr(),
                request.getHeader("User-Agent"));

        // 将日志信息存储为请求的属性，以便后续使用
        request.setAttribute("logInfo", logInfo);
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        // 在请求结束时可以添加额外的处理逻辑
    }
}