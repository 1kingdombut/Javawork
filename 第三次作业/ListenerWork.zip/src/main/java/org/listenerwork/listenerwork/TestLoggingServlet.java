package org.listenerwork.listenerwork;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/testLogging")
public class TestLoggingServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取日志信息
        String logInfo = (String) request.getAttribute("logInfo");

        // 设置响应内容类型为 HTML
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        // 输出 HTML 内容和 JavaScript，将日志信息发送到控制台
        response.getWriter().write("<html><body>");
        response.getWriter().write("<h1>Check the browser console for log details</h1>");
        response.getWriter().write("<script>");
        response.getWriter().write("console.log('Server Log: " + logInfo + "');");
        response.getWriter().write("</script>");
        response.getWriter().write("</body></html>");
    }
}
