package JavawebWork;

import java.sql.*;

public class JDBC_Create {
    static String url = "jdbc:mysql://localhost:3306/DataJDBC";
    static String user = "root";
    static String password = "123456789";
    static String sql = "insert into teacher(id, name, course,birthday ) values(?,?,?,?)";

    public static void main(String[] args) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Date birthday = new Date(2000, 1, 1);
        try {
            con = DriverManager.getConnection(url, user, password);
            ps = con.prepareStatement(sql);
            ps.setInt(1, 2);
            ps.setString(2, "Peter");
            ps.setString(3, "数学");
            ps.setDate(4,birthday );

            ps.executeUpdate();
            System.out.println("成功插入数据");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (rs != null) {
                try
                    {
                        rs.close();
                    }
                catch (SQLException e)
                    {
                        throw new RuntimeException(e);
                    }
            }
            if (ps != null) {
                try
                    {
                        ps.close();
                    }
                catch (SQLException e)
                    {
                        throw new RuntimeException(e);
                    }
            }
            if (con != null) {
                try
                    {
                        con.close();
                    }
                catch (SQLException e)
                    {
                        throw new RuntimeException(e);
                    }
            }
        }
    }
}
