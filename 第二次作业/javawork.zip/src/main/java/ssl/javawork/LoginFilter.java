package ssl.javawork;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter(urlPatterns = "/*")
public class LoginFilter implements Filter {

    private static final List<String> excludedPaths = Arrays.asList( "/login", "/register", "/public","/login.html");

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse httpResponse = (HttpServletResponse) servletResponse;
        String path = httpRequest.getServletPath();


        // 如果请求路径是排除的路径，继续请求
        if (isExcludedPath(path)) {
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        // 获取用户的 session
        HttpSession session = httpRequest.getSession(false);
        // 检查用户是否已登录
        if (session != null && session.getAttribute("user") != null) {
            filterChain.doFilter(servletRequest, servletResponse);
        } else {
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.html");
        }
        System.out.println("Requested Path: " + path);


    }

    private boolean isExcludedPath(String path) {
        return excludedPaths.stream().anyMatch(path::startsWith);
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
        // 可选的清理代码
    }
}
