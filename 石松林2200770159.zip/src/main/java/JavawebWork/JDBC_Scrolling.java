package JavawebWork;

import java.sql.*;

public class JDBC_Scrolling {
    static final String URL = "jdbc:mysql://localhost:3306/DataJDBC";
    static final String USER = "root";
    static final String PASS = "123456789";
    static final String SQL = "select * from teacher where id >?";
    public static void main(String[] args) throws SQLException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            con= DriverManager.getConnection(URL,USER,PASS);
            ps=con.prepareStatement(SQL,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

            ps.setInt(1,5);
            rs=ps.executeQuery();
            rs.absolute(-2);
            System.out.println(rs.getInt("id") + " " + rs.getString("name"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if(rs!=null) rs.close();
            if(ps!=null) ps.close();
            if(con!=null) con.close();
        }
    }
}
